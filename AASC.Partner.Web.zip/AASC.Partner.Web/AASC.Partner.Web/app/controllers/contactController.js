﻿'use strict';
app.controller('contactController', ['$scope', function ($scope) {

    $scope.contactInfo = "Click below link for technical support when you have problem in accessing this site.";

}]);