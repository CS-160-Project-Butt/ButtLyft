﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AASC.Partner.Web.Tests.Models
{
    public class ParentDepartmentViewModel
    {
        public Guid? Id { get; set; }

        public string Name { get; set; }
    }
}
